To generate the html docs, execute
doxygen feature_mos_API_doxyfile

