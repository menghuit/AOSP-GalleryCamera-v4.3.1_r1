To generate the html docs, execute
doxygen dbreg_API_doxyfile

