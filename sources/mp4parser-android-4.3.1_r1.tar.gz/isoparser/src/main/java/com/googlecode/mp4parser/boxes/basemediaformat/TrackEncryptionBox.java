package com.googlecode.mp4parser.boxes.basemediaformat;

import com.googlecode.mp4parser.boxes.AbstractTrackEncryptionBox;

/**
 *
 */
public class TrackEncryptionBox extends AbstractTrackEncryptionBox {
    public TrackEncryptionBox() {
        super("tenc");
    }
}
